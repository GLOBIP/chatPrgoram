#pragma once
#include "ncurses.h"
#include <string>
struct WindowParts;
class Client {

public:
  std::string readValue(int socket);
  int initilizeNetwork(int port, const char *addressIP);
  void closeNetwork(int socket);
  void sendValue(int socket, const char *message);
  std::string catchInput(WINDOW *my_win, int depent);
};
class windowShowProgra {
public:
  // void drawOnScreen(int startx, int &starty, const char *msg);
  void destroy_win(WINDOW *local_win);

  WINDOW *create_newwin(int height, int width, int starty, int startx);
  void catchKeyboard(WindowParts under_winParts, std::string &sendMessage,
                     short &message, WINDOW *under_win, int &textHeight,
                     int bottomHeightChat, int copytextHeight);
};
class files {
public:
  void sendFileServer(std::string message);
  void sendFileClient(std::string message);
  void readFile();
};
class windowFileRelated {
public:
  void putReadIntoScreen(std::string message, int &starty, WindowParts *MyParts,
                         WINDOW *new_win, int &bottomHeightChat);
  void drawOnScreen(int side, WindowParts *MyParts, int &starty,
                    const char *msg, WINDOW *new_win, std::string who);
};
struct WindowParts {

  int height = LINES - 5;
  int width = COLS - 10;
  int starty = 5;
  int startx = 10;
  int left = startx + 2;
  int right = width - 4;
  int under_window_height = 5;
  int upper_window_height = height - 5;
};
class GUI {
  files myfiles;
  windowFileRelated myWindow;
  windowShowProgra myWindowProgram;

public:
  void guiFunc(Client &Internet);
};
