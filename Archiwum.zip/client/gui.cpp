#include "client.h"
#include <cstring>
#include <ncurses.h>
#include <string>
WINDOW *create_newwin(int height, int width, int starty, int startx) {
  WINDOW *local_win;

  local_win = newwin(height, width, starty, startx);
  box(local_win, 0, 0); /* 0, 0 gives default characters
                         * for the vertical and horizontal
                         * lines			*/
  wrefresh(local_win);  /* Show that box 		*/

  return local_win;
}

void makeWindow(windowShowProgra &myWindowProgram, Client &NetworkStuff,
                int &socket) {

  struct FirstIpWindow {
    int height = 10;
    int width = 30;
    int starty = (LINES - height) / 2; /* Calculating for a center placement */
    int startx = (COLS - width) / 2;   /* of the window		*/
    const char *message1 = "Welcome to Client";
    const char *message2 = "give a port";
    const char *message3 = "Give IP";
  };
  WINDOW *my_win;

  FirstIpWindow VarsWindow;

  refresh();
  init_pair(1, COLOR_BLACK, COLOR_CYAN);
  my_win = create_newwin(VarsWindow.height, VarsWindow.width, VarsWindow.starty,
                         VarsWindow.startx);
  wbkgd(my_win, COLOR_PAIR(1));
  refresh();
  mvwprintw(my_win, 1, 7, VarsWindow.message1);
  mvwprintw(my_win, 2, 7, VarsWindow.message2);
  mvwprintw(my_win, 6, 7, VarsWindow.message3);
  wrefresh(my_win);
  std::string port = NetworkStuff.catchInput(my_win, 4);
  std::string IPaddr = NetworkStuff.catchInput(my_win, 7);
  socket = NetworkStuff.initilizeNetwork(std::stoi(port), IPaddr.c_str());
  myWindowProgram.destroy_win(my_win);
}

// MAIN WINDOW
void putText(windowShowProgra &myWindowProgram, WindowParts *windowVariables,
             int height, std::string message, WINDOW *&new_win,
             windowFileRelated &WindowRelated, int &bottomHeightChat) {
  init_pair(3, COLOR_WHITE, COLOR_BLACK);
  new_win = myWindowProgram.create_newwin(
      windowVariables->upper_window_height, windowVariables->width,
      windowVariables->starty, windowVariables->startx);
  wbkgd(new_win, COLOR_PAIR(3));
  WindowRelated.putReadIntoScreen(message, height, windowVariables, new_win,
                                  bottomHeightChat);
  wrefresh(new_win);
}

void writeRecievedData(std::string message1, files &myfiles,
                       windowShowProgra &myWindowProgram, WINDOW *&new_win) {
  myfiles.sendFileServer(message1);
  myWindowProgram.destroy_win(new_win);
}
void makeMainWindow(Client &Internet, windowFileRelated &WindowRelated,
                    int socket, files &myfiles,
                    windowShowProgra &myWindowProgram) {

  WINDOW *new_win;
  WINDOW *under_win;
  WindowParts windowVariables;
  WindowParts *cptr = &windowVariables;
  int writeHeigth = LINES - 6;
  std::string sendMessage = "";
  short writeMessage{3};
  int textHeight = windowVariables.height - 15;
  int copytextHeight = textHeight;
  int bottomHeightChat{};
  refresh();
  putText(myWindowProgram, cptr, textHeight, sendMessage, new_win,
          WindowRelated, bottomHeightChat);
  init_pair(4, COLOR_BLACK, COLOR_CYAN);
  under_win =
      create_newwin(windowVariables.under_window_height, windowVariables.width,
                    windowVariables.height, windowVariables.startx);
  wbkgd(under_win, COLOR_PAIR(4));
  nodelay(new_win, true);
  nodelay(under_win, true);
  nodelay(stdscr, true);
  wrefresh(new_win);

  keypad(under_win, TRUE);
  wrefresh(new_win);
  while (writeMessage) {
    // read server input otherPc
    std::string message1 = Internet.readValue(socket);
    if (!message1.empty()) {
      writeRecievedData(message1, myfiles, myWindowProgram, new_win);
      putText(myWindowProgram, cptr, textHeight, sendMessage, new_win,
              WindowRelated, bottomHeightChat);
    } // write input from keyboard
    myWindowProgram.catchKeyboard(windowVariables, sendMessage, writeMessage,
                                  under_win, textHeight, bottomHeightChat,
                                  copytextHeight);
    if (writeMessage == 2) {
      Internet.sendValue(
          socket, sendMessage.c_str());    // send text to be written by client
      myfiles.sendFileClient(sendMessage); // writes into our file chat
                                           // show file protocol
      myWindowProgram.destroy_win(new_win);
      putText(myWindowProgram, cptr, textHeight, sendMessage, new_win,
              WindowRelated, bottomHeightChat);
      writeMessage = 3;
      sendMessage = "";
      // end
    } else if (writeMessage == 4) {
      myWindowProgram.destroy_win(new_win); // show chat protocol
      putText(myWindowProgram, cptr, textHeight, sendMessage, new_win,
              WindowRelated, bottomHeightChat);
      writeMessage = 1;
    }

    wclrtoeol(under_win);
    wrefresh(under_win);
  }

  // drawOnScreen(right, writeHeigth, "Hello Server");
  // writeHeigth -= 3;

  getch();
  myWindowProgram.destroy_win(under_win);
  myWindowProgram.destroy_win(new_win);
}

void GUI::guiFunc(Client &Internet) {
  initscr();
  start_color();
  init_pair(2, COLOR_BLACK, COLOR_BLUE);
  bkgd(COLOR_PAIR(2));
  keypad(stdscr, TRUE);
  noecho();
  cbreak();
  curs_set(0);
  int socket{};
  makeWindow(myWindowProgram, Internet, socket);
  if (socket != -1)
    makeMainWindow(Internet, myWindow, socket, myfiles, myWindowProgram);

  endwin();
  Internet.closeNetwork(socket);
}
