#include "../comunicator.h"
#include "client.h"
#include <iostream>
#include <unistd.h>
void MainWindow::callClientSide() {
  GUI MyServerProgram;
  Client Internet;

  MyServerProgram.guiFunc(Internet);
}
