#include "client.h"
#include <arpa/inet.h>
#include <cstring>
#include <iostream>
#include <ncurses.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
void Err(std::string type) {
  char bufferErr[256];
  char *error =
      strerror_r(errno, bufferErr,
                 256); // get string message from errno, XSI-compliant version
  std::string errorMsg = error;
  if (type == "socket") {
    if (errorMsg == "EACCES") {
      printf("Access Denied");
    } else if (errorMsg == "EAFNOSUPPORT")
      printf("No support IPv6");
  }

  else if (type == "connect") {
    if (errorMsg == "EACCES")
      printf("write permission denied on the socket file");
    else if (errorMsg == "User tried to connect to broadcast address without "
                         "broadcast flag(not permitted)") {
      printf("address already used");
    } else if (errorMsg == "EADDRINUSE") {
      printf("IP address used");
    } else if (errorMsg == "EAFNOSUPPORT")
      printf("family address not supported");
    else if (errorMsg == "EALREADY")
      printf("the socket is nonblocking previous connection attempt not yet "
             "been completed");
    else if (errorMsg == "ECONNREFUSED")
      printf("on stream socket found no one listening");
  }

  else if (type == "recv") {
    if (errorMsg == "EAGAIN" || errorMsg == "EWOULDBLOCK")
      printf(
          "socket is amrked nonblocking and recieve operation would block or "
          "too late arrived");
    if (errorMsg == "ECONNREFUSED")
      printf("A remote host refused to allow the network connection typically "
             "because it is not running the requested service");
    if (errorMsg ==
        "Resource temporarily unavailable") // NOTHING HAPPENED STILL DO PROGRAM
      return;                               // STILL GOES
  } else if (type == "send") {
    if (errorMsg == "EACCES")
      printf("write permission is denied on the destination socket file");
    if (errorMsg == "EBADF")
      printf("invalid descriptor");
    if (errorMsg == "EISCONN")
      printf("connection-mode socket was connected already but a recipient was "
             "specified");
    if (errorMsg == "ENOTCONN")
      printf("socket not connected no target");
    if (errorMsg == "ENOTSOCK")
      printf("problem with socket");
  }
  endwin();
  std::cout << error << " while doing " << type;
  exit(1);
}
int Client::initilizeNetwork(int port, const char *addressIP) {

  int clientSocket = socket(AF_INET, SOCK_STREAM, 0);
  if (clientSocket == -1)
    Err("socket");

  // specifying address
  sockaddr_in serverAddress;
  serverAddress.sin_family = AF_INET;

  serverAddress.sin_port = htons(port);
  serverAddress.sin_addr.s_addr = inet_addr(addressIP);

  // sending connection request
  int connection = connect(clientSocket, (struct sockaddr *)&serverAddress,
                           sizeof(serverAddress));
  if (connection == -1)
    Err("connect");
  std::string message = "Connected to ";
  message += addressIP;
  mvprintw(1, 1, message.c_str());
  refresh();

  if (connection == -1)
    clientSocket = -1;

  return clientSocket;
}
void Client::closeNetwork(int clientSocket) { close(clientSocket); }
void Client::sendValue(int socket, const char *message) {
  send(socket, message, strlen(message), MSG_DONTWAIT);
}
std::string Client::readValue(int socket) {
  char buffer[1024] = {0};
  ssize_t recieve = recv(socket, buffer, sizeof(buffer), MSG_DONTWAIT);
  std::string StringBuffer = buffer;

  return StringBuffer;
}
std::string Client::catchInput(WINDOW *my_win, int depent) {
  int letter;
  std::string message;
  while (true) {
    letter = getch();
    if (letter == 10 || letter == KEY_ENTER) {
      std::string messageOutput = "Selected: ";
      messageOutput += message;
      mvwprintw(my_win, depent, 3, messageOutput.c_str());
      wrefresh(my_win);
      return message;
    } else if (letter == 127 || letter == KEY_BACKSPACE) {
      if (!message.empty())
        message.pop_back();
    } else if (letter >= 32 && letter <= 127) {
      message.push_back(letter);
    }
    mvwprintw(my_win, depent, 3, message.c_str());
    wrefresh(my_win);
  }
  clrtoeol();
}
