#include "../comunicator.h"
#include "server.h"
#include <iostream>
#include <unistd.h>

void MainWindow::callServerSide() {
  GUIServ MyServerProgram;
  Server Internet;
  MyServerProgram.guiFunc(Internet);
}
